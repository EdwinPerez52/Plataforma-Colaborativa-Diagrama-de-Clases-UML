package com.uagrm.casecase.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;

/**
 * Capa 4: DTO de Entrada para creación y actualización de Paciente
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PacienteRequestDTO {

    @NotBlank(message = "El campo 'ci' no puede estar vacío")
    private String ci;

    @NotBlank(message = "El campo 'ci' no puede estar vacío")
    private String ci;

    @NotBlank(message = "El campo 'nombres' no puede estar vacío")
    private String nombres;

    @NotBlank(message = "El campo 'nombres' no puede estar vacío")
    private String nombres;

    @NotBlank(message = "El campo 'apellidos' no puede estar vacío")
    private String apellidos;

    @NotBlank(message = "El campo 'apellidos' no puede estar vacío")
    private String apellidos;

    @NotNull(message = "El campo 'fechaNacimiento' es obligatorio")
    private LocalDate fechaNacimiento;

    @NotNull(message = "El campo 'fechaNacimiento' es obligatorio")
    private LocalDate fechaNacimiento;

    private String telefono;

    private String telefono;

}
