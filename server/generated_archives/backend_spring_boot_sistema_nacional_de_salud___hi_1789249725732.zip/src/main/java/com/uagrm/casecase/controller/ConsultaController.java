package com.uagrm.casecase.controller;

import com.uagrm.casecase.service.ConsultaService;
import com.uagrm.casecase.dto.request.ConsultaRequestDTO;
import com.uagrm.casecase.dto.response.ConsultaResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

/**
 * Capa 5: Controlador RESTful para la entidad Consulta
 * Endpoints CRUD desacoplados bajo estándar OpenAPI / Spring Web
 */
@RestController
@RequestMapping("/api/v1/con-ultas")
@CrossOrigin(origins = "*")
public class ConsultaController {

    private final ConsultaService consultaService;

    public ConsultaController(ConsultaService consultaService) {
        this.consultaService = consultaService;
    }

    @GetMapping
    public ResponseEntity<List<ConsultaResponseDTO>> getAll() {
        return ResponseEntity.ok(consultaService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ConsultaResponseDTO> getById(@PathVariable Long id) {
        return consultaService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ConsultaResponseDTO> create(@Valid @RequestBody ConsultaRequestDTO request) {
        ConsultaResponseDTO created = consultaService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ConsultaResponseDTO> update(
            @PathVariable Long id,
            @Valid @RequestBody ConsultaRequestDTO request) {
        try {
            return ResponseEntity.ok(consultaService.update(id, request));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        try {
            consultaService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
