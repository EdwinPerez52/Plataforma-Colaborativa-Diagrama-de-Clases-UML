package com.uagrm.casecase.service;

import com.uagrm.casecase.dto.request.ConsultaRequestDTO;
import com.uagrm.casecase.dto.response.ConsultaResponseDTO;
import java.util.List;
import java.util.Optional;

/**
 * Capa 3: Contrato de Servicio de Negocio para Consulta
 */
public interface ConsultaService {

    List<ConsultaResponseDTO> findAll();

    Optional<ConsultaResponseDTO> findById(Long id);

    ConsultaResponseDTO create(ConsultaRequestDTO request);

    ConsultaResponseDTO update(Long id, ConsultaRequestDTO request);

    void delete(Long id);
}
