package com.uagrm.casecase.repository;

import com.uagrm.casecase.entity.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Capa 2: Repositorio Spring Data JPA para la entidad Paciente
 */
@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Long> {

    Optional<Paciente> findByCi(String ci);

}
