package com.uagrm.casecase.service.impl;

import com.uagrm.casecase.entity.Clase6;
import com.uagrm.casecase.repository.Clase6Repository;
import com.uagrm.casecase.service.Clase6Service;
import com.uagrm.casecase.dto.request.Clase6RequestDTO;
import com.uagrm.casecase.dto.response.Clase6ResponseDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredTransConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Capa 3: Implementación Transaccional de Servicios para Clase6
 */
@Slf4j
@Service
@Transactional
public class Clase6ServiceImpl implements Clase6Service {

    private final Clase6Repository clase6Repository;

    public Clase6ServiceImpl(Clase6Repository clase6Repository) {
        this.clase6Repository = clase6Repository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Clase6ResponseDTO> findAll() {
        return clase6Repository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Clase6ResponseDTO> findById(Long id) {
        return clase6Repository.findById(id).map(this::mapToResponse);
    }

    @Override
    public Clase6ResponseDTO create(Clase6RequestDTO request) {
        Clase6 entity = Clase6.builder()
                .build();

        Clase6 saved = clase6Repository.save(entity);
        log.info("[Clase6Service] Creada entidad con ID: {}", saved.getId());
        return mapToResponse(saved);
    }

    @Override
    public Clase6ResponseDTO update(Long id, Clase6RequestDTO request) {
        Clase6 entity = clase6Repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Clase6 no encontrado con ID: " + id));


        Clase6 updated = clase6Repository.save(entity);
        return mapToResponse(updated);
    }

    @Override
    public void delete(Long id) {
        if (!clase6Repository.existsById(id)) {
            throw new RuntimeException("Clase6 no encontrado con ID: " + id);
        }
        clase6Repository.deleteById(id);
        log.info("[Clase6Service] Eliminada entidad con ID: {}", id);
    }

    private Clase6ResponseDTO mapToResponse(Clase6 entity) {
        return Clase6ResponseDTO.builder()
                .id(entity.getId())
                .build();
    }
}
