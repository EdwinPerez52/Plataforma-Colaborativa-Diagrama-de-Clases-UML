package com.uagrm.casecase.controller;

import com.uagrm.casecase.service.Clase7Service;
import com.uagrm.casecase.dto.request.Clase7RequestDTO;
import com.uagrm.casecase.dto.response.Clase7ResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

/**
 * Capa 5: Controlador RESTful para la entidad Clase7
 * Endpoints CRUD desacoplados bajo estándar OpenAPI / Spring Web
 */
@RestController
@RequestMapping("/api/v1/cla-e7s")
@CrossOrigin(origins = "*")
public class Clase7Controller {

    private final Clase7Service clase7Service;

    public Clase7Controller(Clase7Service clase7Service) {
        this.clase7Service = clase7Service;
    }

    @GetMapping
    public ResponseEntity<List<Clase7ResponseDTO>> getAll() {
        return ResponseEntity.ok(clase7Service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Clase7ResponseDTO> getById(@PathVariable Long id) {
        return clase7Service.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Clase7ResponseDTO> create(@Valid @RequestBody Clase7RequestDTO request) {
        Clase7ResponseDTO created = clase7Service.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Clase7ResponseDTO> update(
            @PathVariable Long id,
            @Valid @RequestBody Clase7RequestDTO request) {
        try {
            return ResponseEntity.ok(clase7Service.update(id, request));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        try {
            clase7Service.delete(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
