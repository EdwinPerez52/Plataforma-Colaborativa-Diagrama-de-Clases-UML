package com.uagrm.casecase.service.impl;

import com.uagrm.casecase.entity.Paciente;
import com.uagrm.casecase.repository.PacienteRepository;
import com.uagrm.casecase.service.PacienteService;
import com.uagrm.casecase.dto.request.PacienteRequestDTO;
import com.uagrm.casecase.dto.response.PacienteResponseDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredTransConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Capa 3: Implementación Transaccional de Servicios para Paciente
 */
@Slf4j
@Service
@Transactional
public class PacienteServiceImpl implements PacienteService {

    private final PacienteRepository pacienteRepository;

    public PacienteServiceImpl(PacienteRepository pacienteRepository) {
        this.pacienteRepository = pacienteRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<PacienteResponseDTO> findAll() {
        return pacienteRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<PacienteResponseDTO> findById(Long id) {
        return pacienteRepository.findById(id).map(this::mapToResponse);
    }

    @Override
    public PacienteResponseDTO create(PacienteRequestDTO request) {
        Paciente entity = Paciente.builder()
                .ci(request.getCi())
                .ci(request.getCi())
                .nombres(request.getNombres())
                .nombres(request.getNombres())
                .apellidos(request.getApellidos())
                .apellidos(request.getApellidos())
                .fechaNacimiento(request.getFechaNacimiento())
                .fechaNacimiento(request.getFechaNacimiento())
                .telefono(request.getTelefono())
                .telefono(request.getTelefono())
                .build();

        Paciente saved = pacienteRepository.save(entity);
        log.info("[PacienteService] Creada entidad con ID: {}", saved.getId());
        return mapToResponse(saved);
    }

    @Override
    public PacienteResponseDTO update(Long id, PacienteRequestDTO request) {
        Paciente entity = pacienteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Paciente no encontrado con ID: " + id));

        entity.setCi(request.getCi());
        entity.setCi(request.getCi());
        entity.setNombres(request.getNombres());
        entity.setNombres(request.getNombres());
        entity.setApellidos(request.getApellidos());
        entity.setApellidos(request.getApellidos());
        entity.setFechaNacimiento(request.getFechaNacimiento());
        entity.setFechaNacimiento(request.getFechaNacimiento());
        entity.setTelefono(request.getTelefono());
        entity.setTelefono(request.getTelefono());

        Paciente updated = pacienteRepository.save(entity);
        return mapToResponse(updated);
    }

    @Override
    public void delete(Long id) {
        if (!pacienteRepository.existsById(id)) {
            throw new RuntimeException("Paciente no encontrado con ID: " + id);
        }
        pacienteRepository.deleteById(id);
        log.info("[PacienteService] Eliminada entidad con ID: {}", id);
    }

    private PacienteResponseDTO mapToResponse(Paciente entity) {
        return PacienteResponseDTO.builder()
                .id(entity.getId())
                .ci(entity.getCi())
                .ci(entity.getCi())
                .nombres(entity.getNombres())
                .nombres(entity.getNombres())
                .apellidos(entity.getApellidos())
                .apellidos(entity.getApellidos())
                .fechaNacimiento(entity.getFechaNacimiento())
                .fechaNacimiento(entity.getFechaNacimiento())
                .telefono(entity.getTelefono())
                .telefono(entity.getTelefono())
                .build();
    }
}
