package com.uagrm.casecase.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;

/**
 * Capa 4: DTO de Entrada para creación y actualización de Medico
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MedicoRequestDTO {

    @NotBlank(message = "El campo 'matriculaProfesional' no puede estar vacío")
    private String matriculaProfesional;

    @NotBlank(message = "El campo 'matriculaProfesional' no puede estar vacío")
    private String matriculaProfesional;

    @NotBlank(message = "El campo 'nombreCompleto' no puede estar vacío")
    private String nombreCompleto;

    @NotBlank(message = "El campo 'nombreCompleto' no puede estar vacío")
    private String nombreCompleto;

    @NotBlank(message = "El campo 'especialidad' no puede estar vacío")
    private String especialidad;

    @NotBlank(message = "El campo 'especialidad' no puede estar vacío")
    private String especialidad;

}
