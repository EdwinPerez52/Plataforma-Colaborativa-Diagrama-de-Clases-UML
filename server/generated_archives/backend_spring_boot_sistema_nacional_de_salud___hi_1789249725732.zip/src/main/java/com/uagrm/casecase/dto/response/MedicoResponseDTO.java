package com.uagrm.casecase.dto.response;

import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;

/**
 * Capa 4: DTO de Salida para representar Medico en contratos API REST
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MedicoResponseDTO {

    private Long id;

    private String matriculaProfesional;

    private String matriculaProfesional;

    private String nombreCompleto;

    private String nombreCompleto;

    private String especialidad;

    private String especialidad;

}
