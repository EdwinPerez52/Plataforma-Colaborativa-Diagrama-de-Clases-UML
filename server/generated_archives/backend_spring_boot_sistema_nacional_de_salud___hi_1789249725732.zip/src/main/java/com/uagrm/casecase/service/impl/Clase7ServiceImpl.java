package com.uagrm.casecase.service.impl;

import com.uagrm.casecase.entity.Clase7;
import com.uagrm.casecase.repository.Clase7Repository;
import com.uagrm.casecase.service.Clase7Service;
import com.uagrm.casecase.dto.request.Clase7RequestDTO;
import com.uagrm.casecase.dto.response.Clase7ResponseDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredTransConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Capa 3: Implementación Transaccional de Servicios para Clase7
 */
@Slf4j
@Service
@Transactional
public class Clase7ServiceImpl implements Clase7Service {

    private final Clase7Repository clase7Repository;

    public Clase7ServiceImpl(Clase7Repository clase7Repository) {
        this.clase7Repository = clase7Repository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Clase7ResponseDTO> findAll() {
        return clase7Repository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Clase7ResponseDTO> findById(Long id) {
        return clase7Repository.findById(id).map(this::mapToResponse);
    }

    @Override
    public Clase7ResponseDTO create(Clase7RequestDTO request) {
        Clase7 entity = Clase7.builder()
                .build();

        Clase7 saved = clase7Repository.save(entity);
        log.info("[Clase7Service] Creada entidad con ID: {}", saved.getId());
        return mapToResponse(saved);
    }

    @Override
    public Clase7ResponseDTO update(Long id, Clase7RequestDTO request) {
        Clase7 entity = clase7Repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Clase7 no encontrado con ID: " + id));


        Clase7 updated = clase7Repository.save(entity);
        return mapToResponse(updated);
    }

    @Override
    public void delete(Long id) {
        if (!clase7Repository.existsById(id)) {
            throw new RuntimeException("Clase7 no encontrado con ID: " + id);
        }
        clase7Repository.deleteById(id);
        log.info("[Clase7Service] Eliminada entidad con ID: {}", id);
    }

    private Clase7ResponseDTO mapToResponse(Clase7 entity) {
        return Clase7ResponseDTO.builder()
                .id(entity.getId())
                .build();
    }
}
