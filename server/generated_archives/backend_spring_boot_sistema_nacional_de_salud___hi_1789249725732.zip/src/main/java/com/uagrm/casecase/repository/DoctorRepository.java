package com.uagrm.casecase.repository;

import com.uagrm.casecase.entity.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Capa 2: Repositorio Spring Data JPA para la entidad Doctor
 */
@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {

}
