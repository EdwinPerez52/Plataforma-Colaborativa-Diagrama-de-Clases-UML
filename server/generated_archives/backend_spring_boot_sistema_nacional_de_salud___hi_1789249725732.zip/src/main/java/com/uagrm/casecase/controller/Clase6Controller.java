package com.uagrm.casecase.controller;

import com.uagrm.casecase.service.Clase6Service;
import com.uagrm.casecase.dto.request.Clase6RequestDTO;
import com.uagrm.casecase.dto.response.Clase6ResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

/**
 * Capa 5: Controlador RESTful para la entidad Clase6
 * Endpoints CRUD desacoplados bajo estándar OpenAPI / Spring Web
 */
@RestController
@RequestMapping("/api/v1/cla-e6s")
@CrossOrigin(origins = "*")
public class Clase6Controller {

    private final Clase6Service clase6Service;

    public Clase6Controller(Clase6Service clase6Service) {
        this.clase6Service = clase6Service;
    }

    @GetMapping
    public ResponseEntity<List<Clase6ResponseDTO>> getAll() {
        return ResponseEntity.ok(clase6Service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Clase6ResponseDTO> getById(@PathVariable Long id) {
        return clase6Service.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Clase6ResponseDTO> create(@Valid @RequestBody Clase6RequestDTO request) {
        Clase6ResponseDTO created = clase6Service.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Clase6ResponseDTO> update(
            @PathVariable Long id,
            @Valid @RequestBody Clase6RequestDTO request) {
        try {
            return ResponseEntity.ok(clase6Service.update(id, request));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        try {
            clase6Service.delete(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
