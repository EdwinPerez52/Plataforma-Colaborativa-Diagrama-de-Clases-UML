package com.uagrm.casecase.dto.response;

import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;

/**
 * Capa 4: DTO de Salida para representar Consulta en contratos API REST
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConsultaResponseDTO {

    private Long id;

    private LocalDateTime fechaHora;

    private LocalDateTime fechaHora;

    private String motivo;

    private String motivo;

    private String diagnostico;

    private String diagnostico;

    private BigDecimal costo;

    private BigDecimal costo;

}
