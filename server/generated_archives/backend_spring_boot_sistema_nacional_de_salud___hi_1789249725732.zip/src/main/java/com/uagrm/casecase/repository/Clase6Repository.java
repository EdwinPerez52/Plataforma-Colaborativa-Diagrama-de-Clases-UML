package com.uagrm.casecase.repository;

import com.uagrm.casecase.entity.Clase6;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Capa 2: Repositorio Spring Data JPA para la entidad Clase6
 */
@Repository
public interface Clase6Repository extends JpaRepository<Clase6, Long> {

}
