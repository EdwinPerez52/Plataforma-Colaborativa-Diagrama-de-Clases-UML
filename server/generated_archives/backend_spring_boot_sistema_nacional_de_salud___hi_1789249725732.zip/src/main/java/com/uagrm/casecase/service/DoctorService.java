package com.uagrm.casecase.service;

import com.uagrm.casecase.dto.request.DoctorRequestDTO;
import com.uagrm.casecase.dto.response.DoctorResponseDTO;
import java.util.List;
import java.util.Optional;

/**
 * Capa 3: Contrato de Servicio de Negocio para Doctor
 */
public interface DoctorService {

    List<DoctorResponseDTO> findAll();

    Optional<DoctorResponseDTO> findById(Long id);

    DoctorResponseDTO create(DoctorRequestDTO request);

    DoctorResponseDTO update(Long id, DoctorRequestDTO request);

    void delete(Long id);
}
