package com.uagrm.casecase.service.impl;

import com.uagrm.casecase.entity.Doctor;
import com.uagrm.casecase.repository.DoctorRepository;
import com.uagrm.casecase.service.DoctorService;
import com.uagrm.casecase.dto.request.DoctorRequestDTO;
import com.uagrm.casecase.dto.response.DoctorResponseDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredTransConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Capa 3: Implementación Transaccional de Servicios para Doctor
 */
@Slf4j
@Service
@Transactional
public class DoctorServiceImpl implements DoctorService {

    private final DoctorRepository doctorRepository;

    public DoctorServiceImpl(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<DoctorResponseDTO> findAll() {
        return doctorRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<DoctorResponseDTO> findById(Long id) {
        return doctorRepository.findById(id).map(this::mapToResponse);
    }

    @Override
    public DoctorResponseDTO create(DoctorRequestDTO request) {
        Doctor entity = Doctor.builder()
                .build();

        Doctor saved = doctorRepository.save(entity);
        log.info("[DoctorService] Creada entidad con ID: {}", saved.getId());
        return mapToResponse(saved);
    }

    @Override
    public DoctorResponseDTO update(Long id, DoctorRequestDTO request) {
        Doctor entity = doctorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Doctor no encontrado con ID: " + id));


        Doctor updated = doctorRepository.save(entity);
        return mapToResponse(updated);
    }

    @Override
    public void delete(Long id) {
        if (!doctorRepository.existsById(id)) {
            throw new RuntimeException("Doctor no encontrado con ID: " + id);
        }
        doctorRepository.deleteById(id);
        log.info("[DoctorService] Eliminada entidad con ID: {}", id);
    }

    private DoctorResponseDTO mapToResponse(Doctor entity) {
        return DoctorResponseDTO.builder()
                .id(entity.getId())
                .build();
    }
}
