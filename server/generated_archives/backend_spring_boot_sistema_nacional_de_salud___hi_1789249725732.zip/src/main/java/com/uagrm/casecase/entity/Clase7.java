package com.uagrm.casecase.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;
import java.util.ArrayList;

/**
 * Entidad JPA generada automáticamente para la clase UML: Clase7
 * Capa 1: Entidad de Dominio / Persistencia
 */
@Entity
@Table(name = "clase7s")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Clase7 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

}
