package com.uagrm.casecase.service.impl;

import com.uagrm.casecase.entity.Consulta;
import com.uagrm.casecase.repository.ConsultaRepository;
import com.uagrm.casecase.service.ConsultaService;
import com.uagrm.casecase.dto.request.ConsultaRequestDTO;
import com.uagrm.casecase.dto.response.ConsultaResponseDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredTransConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Capa 3: Implementación Transaccional de Servicios para Consulta
 */
@Slf4j
@Service
@Transactional
public class ConsultaServiceImpl implements ConsultaService {

    private final ConsultaRepository consultaRepository;

    public ConsultaServiceImpl(ConsultaRepository consultaRepository) {
        this.consultaRepository = consultaRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ConsultaResponseDTO> findAll() {
        return consultaRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ConsultaResponseDTO> findById(Long id) {
        return consultaRepository.findById(id).map(this::mapToResponse);
    }

    @Override
    public ConsultaResponseDTO create(ConsultaRequestDTO request) {
        Consulta entity = Consulta.builder()
                .fechaHora(request.getFechaHora())
                .fechaHora(request.getFechaHora())
                .motivo(request.getMotivo())
                .motivo(request.getMotivo())
                .diagnostico(request.getDiagnostico())
                .diagnostico(request.getDiagnostico())
                .costo(request.getCosto())
                .costo(request.getCosto())
                .build();

        Consulta saved = consultaRepository.save(entity);
        log.info("[ConsultaService] Creada entidad con ID: {}", saved.getId());
        return mapToResponse(saved);
    }

    @Override
    public ConsultaResponseDTO update(Long id, ConsultaRequestDTO request) {
        Consulta entity = consultaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Consulta no encontrado con ID: " + id));

        entity.setFechaHora(request.getFechaHora());
        entity.setFechaHora(request.getFechaHora());
        entity.setMotivo(request.getMotivo());
        entity.setMotivo(request.getMotivo());
        entity.setDiagnostico(request.getDiagnostico());
        entity.setDiagnostico(request.getDiagnostico());
        entity.setCosto(request.getCosto());
        entity.setCosto(request.getCosto());

        Consulta updated = consultaRepository.save(entity);
        return mapToResponse(updated);
    }

    @Override
    public void delete(Long id) {
        if (!consultaRepository.existsById(id)) {
            throw new RuntimeException("Consulta no encontrado con ID: " + id);
        }
        consultaRepository.deleteById(id);
        log.info("[ConsultaService] Eliminada entidad con ID: {}", id);
    }

    private ConsultaResponseDTO mapToResponse(Consulta entity) {
        return ConsultaResponseDTO.builder()
                .id(entity.getId())
                .fechaHora(entity.getFechaHora())
                .fechaHora(entity.getFechaHora())
                .motivo(entity.getMotivo())
                .motivo(entity.getMotivo())
                .diagnostico(entity.getDiagnostico())
                .diagnostico(entity.getDiagnostico())
                .costo(entity.getCosto())
                .costo(entity.getCosto())
                .build();
    }
}
