package com.uagrm.casecase.service;

import com.uagrm.casecase.dto.request.Clase7RequestDTO;
import com.uagrm.casecase.dto.response.Clase7ResponseDTO;
import java.util.List;
import java.util.Optional;

/**
 * Capa 3: Contrato de Servicio de Negocio para Clase7
 */
public interface Clase7Service {

    List<Clase7ResponseDTO> findAll();

    Optional<Clase7ResponseDTO> findById(Long id);

    Clase7ResponseDTO create(Clase7RequestDTO request);

    Clase7ResponseDTO update(Long id, Clase7RequestDTO request);

    void delete(Long id);
}
