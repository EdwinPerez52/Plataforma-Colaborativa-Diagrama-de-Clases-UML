package com.uagrm.casecase.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;
import java.util.ArrayList;

/**
 * Entidad JPA generada automáticamente para la clase UML: Clase6
 * Capa 1: Entidad de Dominio / Persistencia
 */
@Entity
@Table(name = "clase6s")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Clase6 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @OneToMany(mappedBy = "clase6", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<Consulta> relacionaList = new ArrayList<>();

}
