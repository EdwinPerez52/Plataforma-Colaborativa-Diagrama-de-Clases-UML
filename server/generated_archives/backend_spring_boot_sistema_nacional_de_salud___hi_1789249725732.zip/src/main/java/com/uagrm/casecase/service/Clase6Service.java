package com.uagrm.casecase.service;

import com.uagrm.casecase.dto.request.Clase6RequestDTO;
import com.uagrm.casecase.dto.response.Clase6ResponseDTO;
import java.util.List;
import java.util.Optional;

/**
 * Capa 3: Contrato de Servicio de Negocio para Clase6
 */
public interface Clase6Service {

    List<Clase6ResponseDTO> findAll();

    Optional<Clase6ResponseDTO> findById(Long id);

    Clase6ResponseDTO create(Clase6RequestDTO request);

    Clase6ResponseDTO update(Long id, Clase6RequestDTO request);

    void delete(Long id);
}
