package com.uagrm.casecase.repository;

import com.uagrm.casecase.entity.Consulta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Capa 2: Repositorio Spring Data JPA para la entidad Consulta
 */
@Repository
public interface ConsultaRepository extends JpaRepository<Consulta, Long> {

    Optional<Consulta> findByMotivo(String motivo);

}
