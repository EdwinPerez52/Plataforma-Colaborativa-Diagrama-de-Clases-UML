package com.uagrm.casecase.repository;

import com.uagrm.casecase.entity.Clase7;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Capa 2: Repositorio Spring Data JPA para la entidad Clase7
 */
@Repository
public interface Clase7Repository extends JpaRepository<Clase7, Long> {

}
