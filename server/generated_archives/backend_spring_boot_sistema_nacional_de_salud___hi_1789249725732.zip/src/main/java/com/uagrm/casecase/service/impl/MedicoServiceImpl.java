package com.uagrm.casecase.service.impl;

import com.uagrm.casecase.entity.Medico;
import com.uagrm.casecase.repository.MedicoRepository;
import com.uagrm.casecase.service.MedicoService;
import com.uagrm.casecase.dto.request.MedicoRequestDTO;
import com.uagrm.casecase.dto.response.MedicoResponseDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredTransConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Capa 3: Implementación Transaccional de Servicios para Medico
 */
@Slf4j
@Service
@Transactional
public class MedicoServiceImpl implements MedicoService {

    private final MedicoRepository medicoRepository;

    public MedicoServiceImpl(MedicoRepository medicoRepository) {
        this.medicoRepository = medicoRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<MedicoResponseDTO> findAll() {
        return medicoRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<MedicoResponseDTO> findById(Long id) {
        return medicoRepository.findById(id).map(this::mapToResponse);
    }

    @Override
    public MedicoResponseDTO create(MedicoRequestDTO request) {
        Medico entity = Medico.builder()
                .matriculaProfesional(request.getMatriculaProfesional())
                .matriculaProfesional(request.getMatriculaProfesional())
                .nombreCompleto(request.getNombreCompleto())
                .nombreCompleto(request.getNombreCompleto())
                .especialidad(request.getEspecialidad())
                .especialidad(request.getEspecialidad())
                .build();

        Medico saved = medicoRepository.save(entity);
        log.info("[MedicoService] Creada entidad con ID: {}", saved.getId());
        return mapToResponse(saved);
    }

    @Override
    public MedicoResponseDTO update(Long id, MedicoRequestDTO request) {
        Medico entity = medicoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Medico no encontrado con ID: " + id));

        entity.setMatriculaProfesional(request.getMatriculaProfesional());
        entity.setMatriculaProfesional(request.getMatriculaProfesional());
        entity.setNombreCompleto(request.getNombreCompleto());
        entity.setNombreCompleto(request.getNombreCompleto());
        entity.setEspecialidad(request.getEspecialidad());
        entity.setEspecialidad(request.getEspecialidad());

        Medico updated = medicoRepository.save(entity);
        return mapToResponse(updated);
    }

    @Override
    public void delete(Long id) {
        if (!medicoRepository.existsById(id)) {
            throw new RuntimeException("Medico no encontrado con ID: " + id);
        }
        medicoRepository.deleteById(id);
        log.info("[MedicoService] Eliminada entidad con ID: {}", id);
    }

    private MedicoResponseDTO mapToResponse(Medico entity) {
        return MedicoResponseDTO.builder()
                .id(entity.getId())
                .matriculaProfesional(entity.getMatriculaProfesional())
                .matriculaProfesional(entity.getMatriculaProfesional())
                .nombreCompleto(entity.getNombreCompleto())
                .nombreCompleto(entity.getNombreCompleto())
                .especialidad(entity.getEspecialidad())
                .especialidad(entity.getEspecialidad())
                .build();
    }
}
