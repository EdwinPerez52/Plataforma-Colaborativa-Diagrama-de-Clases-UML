package com.uagrm.casecase.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;

/**
 * Capa 4: DTO de Entrada para creación y actualización de Consulta
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConsultaRequestDTO {

    @NotNull(message = "El campo 'fechaHora' es obligatorio")
    private LocalDateTime fechaHora;

    @NotNull(message = "El campo 'fechaHora' es obligatorio")
    private LocalDateTime fechaHora;

    @NotBlank(message = "El campo 'motivo' no puede estar vacío")
    private String motivo;

    @NotBlank(message = "El campo 'motivo' no puede estar vacío")
    private String motivo;

    private String diagnostico;

    private String diagnostico;

    @NotNull(message = "El campo 'costo' es obligatorio")
    private BigDecimal costo;

    @NotNull(message = "El campo 'costo' es obligatorio")
    private BigDecimal costo;

}
