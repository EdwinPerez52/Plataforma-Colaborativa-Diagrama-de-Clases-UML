package com.uagrm.casecase.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;

/**
 * Capa 4: DTO de Entrada para creación y actualización de Clase7
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Clase7RequestDTO {

}
