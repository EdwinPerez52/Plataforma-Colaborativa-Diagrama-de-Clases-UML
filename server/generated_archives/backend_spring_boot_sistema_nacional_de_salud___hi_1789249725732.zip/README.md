# Solución Backend Spring Boot 3 (Patrón 5 Capas)

**Proyecto:** Sistema Nacional de Salud - Historial Clínico y Triaje  
**Materia:** Ingeniería de Software 1 — UAGRM  
**Entidades Generadas:** 6  
**Patrón Arquitectónico:** 5 Capas Desacopladas (Entity, Repository, Service, DTO, Controller)  

---

## 1. Estructura Arquitectónica

```text
src/main/java/com/uagrm/casecase/
├── entity/          # Capa 1: Entidades JPA con relaciones y claves foráneas
├── repository/      # Capa 2: Repositorios Spring Data JPA
├── service/         # Capa 3: Interfaces y lógica transaccional de negocio
│   └── impl/
├── dto/             # Capa 4: Contratos de entrada (Request) y salida (Response)
│   ├── request/
│   └── response/
└── controller/      # Capa 5: Endpoints RESTful con validaciones y códigos HTTP
```

---

## 2. Requisitos Previos

* Java Development Kit (JDK) 17 o 21
* Maven 3.8+
* PostgreSQL 17 en ejecución en `localhost:5432` con base de datos `case_collaborative_db`

---

## 3. Ejecución del Proyecto

```bash
# Compilar e iniciar en modo desarrollo
./mvnw spring-boot:run

# O con Maven instalado:
mvn clean spring-boot:run
```

La API REST estará disponible en `http://localhost:8080/api/v1/`.
