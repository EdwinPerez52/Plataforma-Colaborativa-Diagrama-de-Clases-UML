package com.uagrm.casecase.service.impl;

import com.uagrm.casecase.entity.Paciente;
import com.uagrm.casecase.repository.PacienteRepository;
import com.uagrm.casecase.service.PacienteService;
import com.uagrm.casecase.dto.request.PacienteRequestDTO;
import com.uagrm.casecase.dto.response.PacienteResponseDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredTransConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Capa 3: Implementación Transaccional de Servicios para Paciente
 */
@Slf4j
@Service
@Transactional
public class PacienteServiceImpl implements PacienteService {

    private final PacienteRepository pacienteRepository;

    public PacienteServiceImpl(PacienteRepository pacienteRepository) {
        this.pacienteRepository = pacienteRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<PacienteResponseDTO> findAll() {
        return pacienteRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<PacienteResponseDTO> findById(Long id) {
        return pacienteRepository.findById(id).map(this::mapToResponse);
    }

    @Override
    public PacienteResponseDTO create(PacienteRequestDTO request) {
        Paciente entity = Paciente.builder()
                .nombreCompleto(request.getNombreCompleto())
                .historialClinico(request.getHistorialClinico())
                .build();

        Paciente saved = pacienteRepository.save(entity);
        log.info("[PacienteService] Creada entidad con ID: {}", saved.getId());
        return mapToResponse(saved);
    }

    @Override
    public PacienteResponseDTO update(Long id, PacienteRequestDTO request) {
        Paciente entity = pacienteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Paciente no encontrado con ID: " + id));

        entity.setNombreCompleto(request.getNombreCompleto());
        entity.setHistorialClinico(request.getHistorialClinico());

        Paciente updated = pacienteRepository.save(entity);
        return mapToResponse(updated);
    }

    @Override
    public void delete(Long id) {
        if (!pacienteRepository.existsById(id)) {
            throw new RuntimeException("Paciente no encontrado con ID: " + id);
        }
        pacienteRepository.deleteById(id);
        log.info("[PacienteService] Eliminada entidad con ID: {}", id);
    }

    private PacienteResponseDTO mapToResponse(Paciente entity) {
        return PacienteResponseDTO.builder()
                .id(entity.getId())
                .nombreCompleto(entity.getNombreCompleto())
                .historialClinico(entity.getHistorialClinico())
                .build();
    }
}
