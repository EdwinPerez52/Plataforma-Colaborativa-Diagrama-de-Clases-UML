package com.uagrm.casecase.service;

import com.uagrm.casecase.dto.request.ConsultaMedicaRequestDTO;
import com.uagrm.casecase.dto.response.ConsultaMedicaResponseDTO;
import java.util.List;
import java.util.Optional;

/**
 * Capa 3: Contrato de Servicio de Negocio para ConsultaMedica
 */
public interface ConsultaMedicaService {

    List<ConsultaMedicaResponseDTO> findAll();

    Optional<ConsultaMedicaResponseDTO> findById(Long id);

    ConsultaMedicaResponseDTO create(ConsultaMedicaRequestDTO request);

    ConsultaMedicaResponseDTO update(Long id, ConsultaMedicaRequestDTO request);

    void delete(Long id);
}
