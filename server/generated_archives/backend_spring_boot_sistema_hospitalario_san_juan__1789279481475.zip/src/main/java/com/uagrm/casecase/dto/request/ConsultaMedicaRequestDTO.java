package com.uagrm.casecase.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;

/**
 * Capa 4: DTO de Entrada para creación y actualización de ConsultaMedica
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConsultaMedicaRequestDTO {

    @NotNull(message = "El campo 'id' es obligatorio")
    private Long id;

    @NotNull(message = "El campo 'fechaHora' es obligatorio")
    private LocalDateTime fechaHora;

    @NotBlank(message = "El campo 'motivoConsulta' no puede estar vacío")
    private String motivoConsulta;

    @NotNull(message = "El campo 'costo' es obligatorio")
    private BigDecimal costo;

}
