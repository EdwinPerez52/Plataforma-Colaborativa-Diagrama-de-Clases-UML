package com.uagrm.casecase.dto.response;

import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;

/**
 * Capa 4: DTO de Salida para representar ConsultaMedica en contratos API REST
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConsultaMedicaResponseDTO {

    private Long id;

    private Long id;

    private LocalDateTime fechaHora;

    private String motivoConsulta;

    private BigDecimal costo;

}
