package com.uagrm.casecase.service;

import com.uagrm.casecase.dto.request.MedicoRequestDTO;
import com.uagrm.casecase.dto.response.MedicoResponseDTO;
import java.util.List;
import java.util.Optional;

/**
 * Capa 3: Contrato de Servicio de Negocio para Medico
 */
public interface MedicoService {

    List<MedicoResponseDTO> findAll();

    Optional<MedicoResponseDTO> findById(Long id);

    MedicoResponseDTO create(MedicoRequestDTO request);

    MedicoResponseDTO update(Long id, MedicoRequestDTO request);

    void delete(Long id);
}
