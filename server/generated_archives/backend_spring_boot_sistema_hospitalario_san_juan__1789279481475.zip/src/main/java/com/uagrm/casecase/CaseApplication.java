package com.uagrm.casecase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal de inicio para la aplicación generada por Collaborative CASE UML
 * Arquitectura de 5 Capas: Entity, Repository, Service, DTO, Controller
 */
@SpringBootApplication
public class CaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(CaseApplication.class, args);
        System.out.println(">>> Backend Spring Boot 3.3.4 (5 Capas) iniciado exitosamente.");
    }
}
