package com.uagrm.casecase.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;

/**
 * Capa 4: DTO de Entrada para creación y actualización de Paciente
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PacienteRequestDTO {

    @NotBlank(message = "El campo 'nombreCompleto' no puede estar vacío")
    private String nombreCompleto;

    @NotBlank(message = "El campo 'historialClinico' no puede estar vacío")
    private String historialClinico;

}
