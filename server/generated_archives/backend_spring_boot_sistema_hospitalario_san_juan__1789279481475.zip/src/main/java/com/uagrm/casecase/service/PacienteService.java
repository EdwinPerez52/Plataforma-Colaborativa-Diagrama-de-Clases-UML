package com.uagrm.casecase.service;

import com.uagrm.casecase.dto.request.PacienteRequestDTO;
import com.uagrm.casecase.dto.response.PacienteResponseDTO;
import java.util.List;
import java.util.Optional;

/**
 * Capa 3: Contrato de Servicio de Negocio para Paciente
 */
public interface PacienteService {

    List<PacienteResponseDTO> findAll();

    Optional<PacienteResponseDTO> findById(Long id);

    PacienteResponseDTO create(PacienteRequestDTO request);

    PacienteResponseDTO update(Long id, PacienteRequestDTO request);

    void delete(Long id);
}
