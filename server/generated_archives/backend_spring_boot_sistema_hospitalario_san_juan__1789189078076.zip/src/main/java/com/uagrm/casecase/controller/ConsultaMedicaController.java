package com.uagrm.casecase.controller;

import com.uagrm.casecase.service.ConsultaMedicaService;
import com.uagrm.casecase.dto.request.ConsultaMedicaRequestDTO;
import com.uagrm.casecase.dto.response.ConsultaMedicaResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

/**
 * Capa 5: Controlador RESTful para la entidad ConsultaMedica
 * Endpoints CRUD desacoplados bajo estándar OpenAPI / Spring Web
 */
@RestController
@RequestMapping("/api/v1/con-ulta-medicas")
@CrossOrigin(origins = "*")
public class ConsultaMedicaController {

    private final ConsultaMedicaService consultaMedicaService;

    public ConsultaMedicaController(ConsultaMedicaService consultaMedicaService) {
        this.consultaMedicaService = consultaMedicaService;
    }

    @GetMapping
    public ResponseEntity<List<ConsultaMedicaResponseDTO>> getAll() {
        return ResponseEntity.ok(consultaMedicaService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ConsultaMedicaResponseDTO> getById(@PathVariable Long id) {
        return consultaMedicaService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ConsultaMedicaResponseDTO> create(@Valid @RequestBody undefined request) {
        ConsultaMedicaResponseDTO created = consultaMedicaService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ConsultaMedicaResponseDTO> update(
            @PathVariable Long id,
            @Valid @RequestBody undefined request) {
        try {
            return ResponseEntity.ok(consultaMedicaService.update(id, request));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        try {
            consultaMedicaService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
