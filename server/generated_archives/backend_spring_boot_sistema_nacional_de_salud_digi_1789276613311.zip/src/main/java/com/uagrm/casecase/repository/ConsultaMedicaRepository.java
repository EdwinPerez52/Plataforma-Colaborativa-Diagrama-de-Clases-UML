package com.uagrm.casecase.repository;

import com.uagrm.casecase.entity.ConsultaMedica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Capa 2: Repositorio Spring Data JPA para la entidad ConsultaMedica
 */
@Repository
public interface ConsultaMedicaRepository extends JpaRepository<ConsultaMedica, Long> {

    Optional<ConsultaMedica> findByMotivo(String motivo);

}
