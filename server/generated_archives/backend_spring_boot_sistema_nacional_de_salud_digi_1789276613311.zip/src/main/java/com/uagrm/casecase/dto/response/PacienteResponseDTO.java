package com.uagrm.casecase.dto.response;

import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;

/**
 * Capa 4: DTO de Salida para representar Paciente en contratos API REST
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PacienteResponseDTO {

    private Long id;

    private String nombreCompleto;

    private String documentoIdentidad;

    private LocalDate fechaNacimiento;

    private Boolean activo;

}
