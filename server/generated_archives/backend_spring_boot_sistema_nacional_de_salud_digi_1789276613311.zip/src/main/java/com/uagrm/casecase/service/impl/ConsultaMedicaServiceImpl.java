package com.uagrm.casecase.service.impl;

import com.uagrm.casecase.entity.ConsultaMedica;
import com.uagrm.casecase.repository.ConsultaMedicaRepository;
import com.uagrm.casecase.service.ConsultaMedicaService;
import com.uagrm.casecase.dto.request.ConsultaMedicaRequestDTO;
import com.uagrm.casecase.dto.response.ConsultaMedicaResponseDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredTransConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Capa 3: Implementación Transaccional de Servicios para ConsultaMedica
 */
@Slf4j
@Service
@Transactional
public class ConsultaMedicaServiceImpl implements ConsultaMedicaService {

    private final ConsultaMedicaRepository consultaMedicaRepository;

    public ConsultaMedicaServiceImpl(ConsultaMedicaRepository consultaMedicaRepository) {
        this.consultaMedicaRepository = consultaMedicaRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ConsultaMedicaResponseDTO> findAll() {
        return consultaMedicaRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ConsultaMedicaResponseDTO> findById(Long id) {
        return consultaMedicaRepository.findById(id).map(this::mapToResponse);
    }

    @Override
    public ConsultaMedicaResponseDTO create(ConsultaMedicaRequestDTO request) {
        ConsultaMedica entity = ConsultaMedica.builder()
                .motivo(request.getMotivo())
                .costo(request.getCosto())
                .fechaHora(request.getFechaHora())
                .build();

        ConsultaMedica saved = consultaMedicaRepository.save(entity);
        log.info("[ConsultaMedicaService] Creada entidad con ID: {}", saved.getId());
        return mapToResponse(saved);
    }

    @Override
    public ConsultaMedicaResponseDTO update(Long id, ConsultaMedicaRequestDTO request) {
        ConsultaMedica entity = consultaMedicaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("ConsultaMedica no encontrado con ID: " + id));

        entity.setMotivo(request.getMotivo());
        entity.setCosto(request.getCosto());
        entity.setFechaHora(request.getFechaHora());

        ConsultaMedica updated = consultaMedicaRepository.save(entity);
        return mapToResponse(updated);
    }

    @Override
    public void delete(Long id) {
        if (!consultaMedicaRepository.existsById(id)) {
            throw new RuntimeException("ConsultaMedica no encontrado con ID: " + id);
        }
        consultaMedicaRepository.deleteById(id);
        log.info("[ConsultaMedicaService] Eliminada entidad con ID: {}", id);
    }

    private ConsultaMedicaResponseDTO mapToResponse(ConsultaMedica entity) {
        return ConsultaMedicaResponseDTO.builder()
                .id(entity.getId())
                .motivo(entity.getMotivo())
                .costo(entity.getCosto())
                .fechaHora(entity.getFechaHora())
                .build();
    }
}
